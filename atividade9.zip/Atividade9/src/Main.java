// Main Class
public class Main {
    public static void main(String[] args) {
        SortModel model = new SortModel();
        SortController controller = new SortController(model);
        SortView view = new SortView();

        // Utilizando QuickSort
        controller.sortUsingQuickSort();
        int[] sortedNumbers = model.getNumbers();

        // Exibindo os números ordenados
        view.printNumbers(sortedNumbers);
    }
}