// Controller
public class SortController {
    private SortModel model;

    public SortController(SortModel model) {
        this.model = model;
    }

    public void sortUsingQuickSort() {
        model.sortUsingQuickSort();
    }
}
