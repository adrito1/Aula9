// Model
public class SortModel {
    private int[] numbers;

    public SortModel() {
        numbers = new int[10]; // Armazena 10 números
        initializeNumbers(); // Inicializa os números
    }

    private void initializeNumbers() {
        // Inicializa os números como no exemplo fornecido
        numbers[0] = 30;
        numbers[1] = 20;
        numbers[2] = 10;
        numbers[3] = 40;
        numbers[4] = 50;
        numbers[5] = 60;
        numbers[6] = 70;
        numbers[7] = 80;
        numbers[8] = 90;
        numbers[9] = 100;
    }

    public int[] getNumbers() {
        return numbers;
    }

    // Método para ordenar usando o QuickSort
    public void sortUsingQuickSort() {
        quickSort(numbers, 0, numbers.length - 1);
    }

    private void quickSort(int[] vetor, int inicio, int fim) {
        if (inicio < fim) {
            int posicaoPivo = separar(vetor, inicio, fim);
            quickSort(vetor, inicio, posicaoPivo - 1);
            quickSort(vetor, posicaoPivo + 1, fim);
        }
    }

    private int separar(int[] vetor, int inicio, int fim) {
        int pivo = vetor[inicio];
        int i = inicio + 1, f = fim;
        while (i <= f) {
            if (vetor[i] <= pivo) {
                i++;
            } else if (pivo < vetor[f]) {
                f--;
            } else {
                int troca = vetor[i];
                vetor[i] = vetor[f];
                vetor[f] = troca;
                i++;
                f--;
            }
        }

        vetor[inicio] = vetor[f];
        vetor[f] = pivo;
        return f;
    }
}