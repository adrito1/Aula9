// View
public class SortView {
    public void printNumbers(int[] numbers) {
        for (int valor : numbers) {
            System.out.println(valor);
        }
    }
}